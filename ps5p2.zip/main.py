item = input("Would you like a case of pepsi or cocacola? ")
quanity = float(input("How much of this item do you want? "))

if item=="pepsi":
  unitPrice = 10.00
else:
  unitPrice = 20.00

extPrice = quanity*unitPrice

print("Item: ", item)
print("Unit Price: $", unitPrice)
print("Extended Price: $", extPrice)