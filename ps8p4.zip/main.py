list = ['apple', 10, .50, 'banana', 15, 1.00, 'pear', 8, .75]
extPrice = 0
total = 0
price = 0
quanity = 0
orders = 0
averageOrder = 0

for v in list:
  if isinstance(v,str):
    print('Item =' , v)
  elif isinstance(v,int):
    quanity = v
    orders += v
    print('Quanity =' , v)
  elif isinstance(v,float):
    price = v
    print('Price =' , v)
  if not isinstance(v,str) and not isinstance(v,int):
    extPrice = quanity*price
    total += extPrice
    print('Extended Price: $' ,extPrice)
print('Total Extended Price: $' ,total)
print('Total Orders: ' ,orders)
averageOrder = orders/3
print('Average Order: ', averageOrder)