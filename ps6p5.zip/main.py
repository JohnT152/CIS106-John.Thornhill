lName = input("Enter employee last name ")
salary = float(input("Enter salary amount "))
jobLevel = float(input("Enter job level "))

if jobLevel >= 10:
  bonusRate = 0.25
elif jobLevel >= 5:
  bonusRate = 0.2
else:
  bonusRate = 0.1

bonus = salary * bonusRate

print("Last Name: ", lName)
print("Bonus amount: $", bonus)