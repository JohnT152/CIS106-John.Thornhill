books = float(input("How many books would you like? "))
unitPrice = float(input("What's the cost per book? "))
extPrice = books*unitPrice  

if extPrice>50.00:
  shipping = 0
else:
  shipping = 25.00

total = extPrice+shipping

print("Your total not including shipping is: $", extPrice)
print("Shipping cost: $", shipping)
print("Your Total is: $", total)