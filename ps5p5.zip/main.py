lastName = input("What is your last name? ")
grossIncome = float(input("What is your gross income? "))
dependents = float(input("How many dependents? "))

adjGrossIncome = grossIncome - 12000.00 * dependents

if adjGrossIncome > 50000.00:
  tax = adjGrossIncome * 0.20
else:
  tax = adjGrossIncome * 0.10

if tax < 0:
  tax = 100.00

print("Last Name: ", lastName)
print("Gross Income: $", grossIncome)
print("Number of dependents: ", dependents)
print("Adjusted gross income: $", adjGrossIncome)
print("Income tax: $", tax)