for count in range (1,11,2):
 print(count)
  
for number in range (11):
  print(number)

p = float(input("Enter Principle"))
r = float(input("Enter Interest Rate"))

for count in range (1,6, ):
  i = p * r
  eb = p + i
  print(count, "   ", p, "   ", eb)
  p = eb