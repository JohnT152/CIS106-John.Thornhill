qTickets = float(input("Enter amount of tickets "))

if qTickets >= 25:
  ticketPrice = 50
elif qTickets >= 10:
  ticketPrice = 60
elif qTickets >= 5:
  ticketPrice =  70
else:
  ticketPrice = 75

total = qTickets * ticketPrice

print("Number of tickets: ", qTickets)
print("Price per ticket: $", ticketPrice)
print("Total: $", total)