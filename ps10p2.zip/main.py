def averageExam(e1, e2, e3):
  total = e1 + e2 + e3
  average = total / 3
  return average,total

#inputs
lastName = input("Enter your last name: ")
exam1 = float(input("Enter your exam 1 grade: "))
exam2 = float(input("Enter your exam 2 grade: "))
exam3 = float(input("Enter your exam 3 grade: "))
average,total = averageExam(exam1, exam2, exam3)

#prints
print("Last Name: " ,lastName)
print("Exam Average: " ,average)
print("Total Exam Score: " ,total)