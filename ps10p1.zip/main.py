def discount(price, qty, discountRate):
  total = price * qty
  discountAmount = total * discountRate
  discountTotal = total - discountAmount
  return discountAmount,discountTotal

#inputing
qty = float(input("Enter Quanity "))
price = float(input("Enter Price "))
discountRate = float(input("Enter Discount Rate "))
discountAmount,discountTotal = discount(price,qty,discountRate)

#printing
print("Quanity: " ,qty)
print("Price: " ,price)
print("Discount Amount: ",discountAmount)
print("Discount Total: ",discountTotal)