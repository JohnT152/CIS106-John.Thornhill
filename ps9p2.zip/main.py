def findAverage(hits, bats):
  average = hits / bats
  return average

lastName = input("Enter last name: ")
hits = int(input("Enter Number of Hits: "))
bats = int(input("Enter Number of Bats: "))
average = findAverage(hits, bats)
print("Last Name: ", lastName)
print("Batting Average: ", average)