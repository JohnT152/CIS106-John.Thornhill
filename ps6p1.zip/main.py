widgets = float(input("Enter your number of widgets "))

if widgets > 10000.00:
  price = 10
elif widgets > 5000.00:
  price = 20
else:
  price = 30

extPrice = widgets * price
tax = extPrice * 0.07
total = extPrice + tax

print("Your extended price: $", extPrice)
print("Tax amount: $", int(tax))
print("Total: $", total)