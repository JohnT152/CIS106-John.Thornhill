partNumber = float(input("Enter your part number "))
quanity = float(input("Enter the quanity "))

if partNumber == 10 or partNumber == 55:
  unitPrice = 1
elif partNumber == 99:
  unitPrice = 2
elif partNumber == 80 or partNumber == 70:
  unitPrice = 3
else:
  unitPrice = 5

total = quanity * unitPrice

print("Part Number: ", partNumber)
print("Cost per Unit: $", unitPrice)
print("Total: $", total)