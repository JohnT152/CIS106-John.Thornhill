def compPay(jobCode):
  if jobCode == "L" or jobCode == "l":
    payRate = 25
    return payRate
  elif jobCode == "A" or jobCode == "a":
    payRate = 30
    return payRate
  elif  jobCode == "J" or jobCode == "j":
    payRate = 50
    return payRate
  
def compGross(hours, payRate):
  if hours > 40:
    hours -= 40
    overtime = hours * payRate * 1.5
    hours += 40
    grossPay = hours * payRate + overtime
    return grossPay
  else:
    grossPay = hours * payRate
    return grossPay

lastName = input("Enter Last Name: ")
jobcode = input("Enter Job Code: ")
hours = float(input("Enter Hours Worked: "))
payRate = compPay(jobcode)
grossPay = compGross(hours, payRate)
print("Last Name: ", lastName)
print("Gross Pay: $", grossPay)