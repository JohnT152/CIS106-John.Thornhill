list = ['thornhill', 'I', 12, 'johnson', 'O', 8, 'jackson', 'O', 16]
tuition = 0
credits = 0
price = 0
totalTuition = 0
students = 3

for v in list:
  if isinstance(v,str):
    tuition = 0
    if v == 'I' or v == 'O':
      if v== 'I':
        tuition += 250
      else:
        tuition += 500
      print('District Code: ' , v)
    else:
      print('Last Name :' , v)
  elif isinstance(v,int):
    print('Credits Taken: ' ,v)
    tuition *= v
    totalTuition += tuition
    print('Tuition Owed: $' ,tuition)
print('Total Tuition: $' , totalTuition)
print('Number Of Students: ' ,students)