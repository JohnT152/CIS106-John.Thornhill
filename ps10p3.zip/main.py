def salesReport(sales):
  if sales > 100000.00:
    rate = 0.1
  else:
    rate = 0.05
  commision = sales * rate
  nextYear = sales * 1.05
  return commision,nextYear

#inputs
name = input("Enter Salesperson's Last Name: ")
sales = float(input("Enter Sales Amount: "))
commision,nextYear = salesReport(sales)

#prints
print("Salesperson: " ,name)
print("Sales: " ,sales)
print("Commision: " ,commision)
print("Next Year Sales: " ,nextYear)