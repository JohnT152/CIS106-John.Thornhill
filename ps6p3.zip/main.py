principle = float(input(" Enter principle of CD "))
yMaturity = float(input("Enter years til maturity "))

if principle > 100000.00 and yMaturity == 5:
  interestRate = 0.06
elif principle > 50000.00 and yMaturity == 10:
  interestRate = 0.05
elif principle > 50000.00 and yMaturity == 5:
  interestRate = 0.04
else:
  interestRate = 0.02

firstYearRate = principle * interestRate

print("Principle: ", principle)
if interestRate == 0.06:
  print("Interest Rate: 6%")
elif interestRate == 0.05:
  print("Interest Rate: 5%")
elif interestRate == 0.04:
    print("Interest Rate: 4%")
else:
    print("Interest Rate: 2%")
print("Interest amount for first year: ", firstYearRate)