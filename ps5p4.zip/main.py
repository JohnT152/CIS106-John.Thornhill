appliance = input("What appliance would you like? ")
unitPrice = float(input("What is the price of this appliance? "))

if unitPrice>1000.00:
  warranty = unitPrice*0.1
else:
  warranty = unitPrice*0.05

total = unitPrice+warranty

print("Appliance: ", appliance)
print("Cost of appliance: $", unitPrice)
print("Warranty price: $", warranty)
print("Your total is: $", total)