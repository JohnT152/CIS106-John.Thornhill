list = ["Smith", 100000.00, "Adams", 75000.00, "Mars", 500000.00]
list += ["Davis", 20000.00, "Sendil", 250000.00]
total = 0
for v in list:
  if isinstance(v,str):
    print('Employee =' , v)
  elif v > 100000.00:
    print('salary =' , v)
    v *= 0.2
    print('bonus =' , v)
    total += v
  elif v > 50000.00:
    print('salary =' , v)
    v *= 0.15
    print('bonus =' , v)
    total += v
  else:
    print('salary =' , v)
    v *= .1
    print('bonus =' , v)
    total += v
print('Total Bonuses =' , total)
