seq = [1,1]
for i in range(18):
    seq.append(seq[-1] + seq[-2])
print(seq)