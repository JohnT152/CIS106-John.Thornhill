def bowlingAverage(score1,score2,score3,handiCap):
  total = score1 + score2 + score3
  average = total/3
  handiCapAverage = (total + handiCap) / 3
  return average,handiCapAverage

#inputs
lastname = input("Enter Last Name: ")
score1 = float(input("Enter Score 1: "))
score2 = float(input("Enter Score 2: "))
score3 = float(input("Enter Score 3: "))
handiCap = float(input("Enter Handicap Amount: "))
average,handiCapAverage = bowlingAverage(score1,score2,score3,handiCap)

#prints
print("Last Name: ",lastname)
print("Score Average: ",average)
print("Handicap Average: ",handiCapAverage)