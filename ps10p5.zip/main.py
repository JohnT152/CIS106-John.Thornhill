total = 0.00
tax = 0.00
def compTotal(qty,price):
  global total
  total = qty * price
  global tax  
  tax = total * .07
  return

#inputs
qty = float(input("Enter quantity: "))
price = float(input("Enter price Per Unit: "))
compTotal(qty,price)

#prints
print("Your Total: $",total)
print("Your Tax: $",tax)