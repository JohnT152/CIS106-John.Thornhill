def compTuition(credHours, disCode):
  if disCode == "I" or disCode == "i":
    credCost = 250
    tuition = credHours * credCost
    return tuition
  elif disCode == "O" or disCode == "o":
    credCost = 550
    tuition = credHours * credCost
    return tuition

lastName = input("Enter student's last name: ")
disCode = input("Enter student's district code: ")
credHours = int(input("Enter credit hours: "))
tuition = compTuition(credHours, disCode)
print("Last Name: ", lastName)
print("Tuition Owed: $", tuition)