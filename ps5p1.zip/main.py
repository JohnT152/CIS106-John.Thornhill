quanity = float(input("Enter amount of item "))


if quanity >= 1000.00:
  unitPrice = 3.00
else:
  unitPrice = 5.00

extPrice = quanity*unitPrice
tax = extPrice*0.07
total = extPrice+tax

print("Quanity of Item: ", quanity)
print("Unit Price: $", unitPrice)
print("Extended Price: $", extPrice)
print("Tax: $", tax)
print("Total: $", total)