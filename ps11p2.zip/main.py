names = ['John', 'Eric', 'Jessica', 'Michelle', 'Ashley', 'Samantha', 'Kyle', 'Jason', 
   'Logan', 'Taylor']
scores = ['75', '85', '60', '45', '90', '100', '70', '80', '95', '85']

def displayName():
  for i in range(0,10):
    print(names[i], " Exam Score: ",scores[i])

def displayNameReverse():
  for i in range(len(names)-1,-1,-1):
    print(names[i], " Exam Score: ",scores[i])

whichDisplay = input("Would you like the names displayed in 'normal' order or in 'reverse' order? ")

if whichDisplay == "normal" or whichDisplay == "Normal":
  displayName()
else:
  displayNameReverse()