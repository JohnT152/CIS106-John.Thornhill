def comptotal(qty, price):
  total = float(qty) * float(price)

  if total > 10000.00:
    total *= 0.90
  else:
    total = total

  return total
  
qty = float(input("Enter   Quanity"))
price = float(input("Enter Price"))
total = comptotal(qty, price)
print("Quanity: ", qty)
print("Price: $", price)
print("Total is $", total)