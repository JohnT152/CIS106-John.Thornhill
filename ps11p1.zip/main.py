names = ['John', 'Eric', 'Jessica', 'Michelle', 'Ashley', 'Samantha', 'Kyle', 'Jason', 
         'Logan', 'Taylor']

def displayName():
  for i in names:
    print(i)

def displayNameReverse():
  for i in reversed(names):
    print(i)

whichDisplay = input("Would you like the names displayed in 'normal' order or in 'reverse' order? ")

if whichDisplay == "normal" or whichDisplay == "Normal":
  displayName()
else:
  displayNameReverse()