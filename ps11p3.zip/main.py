def loadData(file_path):
  data = []
  with open(file_path, 'r') as file:
      for line in file:
          last_name, score = line.strip().split()
          data.append({'last_name': last_name, 'score': int(score)})
  return data

def find_highest_lowest(data):
  high_var = 0
  low_var = 999
  high_index = 0
  low_index = 0

  for i, record in enumerate(data):
      score = record['score']

      # Finding highest
      if score > high_var:
          high_var = score
          high_index = i

      # Finding lowest
      if score < low_var:
          low_var = score
          low_index = i

  return high_index, low_index

def displayResults(data, high_index, low_index):
  print(f'Highest: Last Name - {data[high_index]["last_name"]}, Score - {data[high_index]["score"]}')
  print(f'Lowest: Last Name - {data[low_index]["last_name"]}, Score - {data[low_index]["score"]}')

if __name__ == "__main__":
  data = loadData("scores.txt")

  high_index, low_index = find_highest_lowest(data)
  displayResults(data, high_index, low_index)