def compMpg(miles, gallons):
  mpg = miles / gallons
  return mpg

def compCost(gallons, cost):
  total = gallons * cost
  return total

city = input("Enter Destination City: ")
miles = float(input("Enter Miles Driven: "))
gallons = float(input("Enter Gallons Used: "))
cost = 2.50
mpg = compMpg(miles, gallons)
total = compCost(gallons, cost)
print("Destination: ", city)
print("Miles Traveled: ", miles)
print("Gallons Used: ", gallons)
print("Cost of Gas: ", total)
print("Miles Per Gallon: ", mpg)